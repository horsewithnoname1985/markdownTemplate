#!/bin/bash
cd "$(dirname "$0")"
pandoc -f markdown --template=el_template_en.html --css RobotFramework.css -t html "dsfdsfds_v1.0.markdown" -o "dsfdsfds_v1.0.html"
