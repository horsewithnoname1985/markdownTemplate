#!/bin/bash
cd "$(dirname "$0")"
pandoc -f markdown --template=el_template_en.html --css Default.css -t html "sadasd_v1.0.markdown" -o "sadasd_v1.0.html"
