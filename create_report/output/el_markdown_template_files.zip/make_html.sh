#!/bin/bash
cd "$(dirname "$0")"
pandoc -f markdown --template=el_template_en.html --css E+L_style.css -t html "sada_v1.0.markdown" -o "sada_v1.0.html"
